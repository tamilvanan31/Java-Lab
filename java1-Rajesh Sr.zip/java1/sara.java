import java.lang.*;
class B
{
	public static void main(String args[])
	{
		int a=4,b=5,c;
		c=a+b;
		System.out.println(c);
	}
}
