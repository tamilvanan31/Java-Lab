import java.util.*;
class Validdate1
{
	public static void main(String args[])
	{
		int[] arr=new int[10];
		Scanner sc=new Scanner(System.in);
		arr=sc.nextline();
	}
}
