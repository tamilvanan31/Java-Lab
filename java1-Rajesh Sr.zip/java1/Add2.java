class Add2
{
	
	public static void main(String []args)
	{
		int x1,x2,x3;
		scanner a=new scanner(system.in);
		a.x1=nextInt();
		a.x2=nextInt();
		a.x3=nextInt();
		system.out.println(x1" "+x2+" "+x3);
		
