import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;
class Simple
{public static void main(String args[]) throws IOException
{Scanner in=new Scanner(System.in);
float f=in.nextFloat();
int i=in.nextInt();
System.out.println("hello java");
//System.out.println(m);
//BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
//String name=reader.readLine();
System.out.println(i);
}
}
