import java.lang.*;
import java.util.*;
class Validdate
{
	public static void main(String args[])
	{
		String d;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a date");
		d=sc.nextLine();
		//System.out.println(d);
		String[] i=d.split("/");
		//for(int j=0;j<3;j++)
		//	System.out.println(i[j]);
		int valid,d1,m,y;
		d1=i[0];
		//if(i[0]>0 && i[0]<29)
		//	v=0;
	}
}
