class WrapperExample
{
	public static void main(String[] args)
	{
		int i=10;
		Integer j=i;
		Float fl=new Float(10.5);
		float f=fl;
		System.out.println(f+" "+fl);
	}
}
