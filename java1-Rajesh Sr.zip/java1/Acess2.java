package acess2;
import acess.*;
public class Acess2
{
	public void setPublicVal(Acess p,String n)
	{
		p.name=n;
	}
	public void printVal(Acess p)
	{
		System.out.println("Name :"+p.name);
	}
}
