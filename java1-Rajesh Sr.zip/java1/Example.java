class Example
{
public static void main(String[] args)
{
String s="geeksforgeeks";
int op=s.indexOf('f',2);
System.out.println(op);
}
}
