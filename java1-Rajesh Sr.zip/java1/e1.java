class Parent
{
	int x;
	Parent(int y)
	{
		x=y;
	}
}
class Child 
{
	public static void main(String[] args)
	{
		Parent p=new Parent(5);
	}
}
