import java. util. Scanner;
public class Solution {

	public static void main(String[] args){
		Scanner input = new Scanner(System. in);
		System. out. println("Enter strings:");
		String a = input. nextLine();
		//for(int i = 0; i < a. length; i++)
		System. out. println(a);
	}
}
/*   Scanner in = new Scanner(System.in);
        int t=in.nextInt();
        for(int i=0;i<t;i++){
            int a = in.nextInt();
            int b = in.nextInt();
            int n = in.nextInt();
        }
        in.close();*/
