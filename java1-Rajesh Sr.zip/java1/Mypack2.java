package mypack2;
public class Mypack2
{
	public void display()
	{
		System.out.println("My package 2");
	}
}
