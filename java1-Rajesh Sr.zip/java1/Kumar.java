class Person extends Student
{
	int i;
}
class Student
{
	double k;
}
class Kumar
{
	public static void main(String arg[])
	{
		Student obj=new Person();
	}
}		
