import java.lang.*;
import java.util.*;
class Noofchar
{
	public static void main(String args[])
	{
		String s;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		s=sc.nextLine();
		System.out.println(s.length());
	}
}
