class hj
{
	public static void main(String []args)
	{
		int i=1,n=2,j=i*n;
		System.out.println(+i +"*" +n +"="+j);
	}
}
